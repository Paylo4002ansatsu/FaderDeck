# FaderDeck para macOS · app desktop

O FaderDeck para macOS reúne o painel, a ponte MIDI e o QR de pareamento em um único app. O ícone permanece na barra de menus enquanto a ponte está ativa; fechar a janela apenas a esconde. O app cria a porta MIDI virtual **FaderDeck** automaticamente. Computador e celular precisam estar na mesma rede local.

## Instalar e abrir no macOS

1. Instale o Node.js 20 ou superior (versão LTS) e confirme no Terminal com `node -v` e `npm -v`.
2. Baixe o código-fonte, abra o Terminal na pasta do projeto e rode `npm install`. Na primeira instalação do módulo MIDI nativo, o macOS pode pedir ferramentas de compilação; se falhar, instale-as com `xcode-select --install` e tente novamente.
3. Para executar em desenvolvimento, use `npm run dev`.
4. Para gerar o instalador de distribuição, use `npm run dist`. O Electron Builder gera o DMG e o ZIP universais (Intel e Apple Silicon) em `release/`. A criação dos artefatos macOS deve ser feita em um Mac.
5. Abra o arquivo `.dmg`, arraste **FaderDeck** para **Aplicativos** e abra o app.
6. Como o app ainda não está assinado/notarizado, o macOS poderá avisar que o desenvolvedor não pôde ser verificado. Para abrir, clique com o botão direito (ou Control-clique) em FaderDeck.app, escolha **Abrir** e confirme; se necessário, permita em **Ajustes do Sistema → Privacidade e Segurança**.
7. No primeiro uso, permita o acesso à rede local quando o macOS perguntar. Se o iPhone não conectar, confira **Ajustes do Sistema → Rede → Firewall → Opções** e permita conexões de entrada para FaderDeck. Computador e iPhone devem estar no mesmo Wi‑Fi; redes de convidados podem impedir a comunicação entre aparelhos.

## Parear o celular

Ao iniciar, o app abre uma tela de boas-vindas com QR, endereço IP e porta. Escaneie o QR com a câmera do iPhone. Se a porta 8787 já estiver ocupada, o app escolhe a próxima porta disponível e mostra o endereço atualizado. O menu da barra oferece **Abrir painel**, **Mostrar QR e endereço do celular**, **Copiar link do celular**, **Portas MIDI (/bridge)**, **Renovar código**, **Abrir ao iniciar o Mac** e **Sair**.

A janela principal mostra o painel do FaderDeck. Fechá-la não encerra o app: clique no ícone na barra de menus para reabri-la. O indicador do ícone/tooltip informa se há aparelhos conectados e quantos.

## Dados e atualizações

O layout, o código de pareamento e os dados locais do painel (incluindo presets e backups do armazenamento do navegador) ficam em `~/Library/Application Support/FaderDeck`, fora do app. Atualizar ou substituir o FaderDeck não deve apagar esses dados. Se os arquivos antigos `.faderdeck-token` e `faderdeck-layout.json` forem encontrados na pasta antiga `fader-bridge`, o app os copia para a pasta de dados na primeira inicialização, sem sobrescrever arquivos existentes. Para manter cópia de segurança, feche o app e copie essa pasta de dados para um local seguro.

**Renovar código** gera um novo código de pareamento e desconecta aparelhos pareados anteriormente; escaneie novamente o QR nos celulares. Se existir uma porta IAC com o mesmo nome **FaderDeck**, use apenas uma das duas para evitar duplicidade MIDI.

## Ponte Node independente

O pacote `fader-bridge.zip` continua disponível para executar a ponte sem o app Electron. Extraia o ZIP, instale Node.js 20+, rode `npm install` e depois `npm start`. No macOS, a ponte cria automaticamente a porta MIDI virtual **FaderDeck**; o painel de configuração e QR fica em `http://localhost:8787/bridge`. Mantenha o processo aberto enquanto usar a ponte.

## Configurar a DAW

Os nomes exatos dos menus variam conforme a versão e o idioma. Pads de Program Change enviam um disparo de seleção de programa; pads Note/CC podem ser momentâneos ou toggle.

| DAW | Habilitar a entrada | Aprender um parâmetro |
| --- | --- | --- |
| **ChurchDAW** | Abra a aba **Áudio e MIDI** e habilite como entrada MIDI a porta virtual **FaderDeck**. | Ative **Mapear MIDI**, selecione o controle da DAW e mova o fader/pad no FaderDeck. O mapeamento fica salvo no projeto. |
| **Ableton Live** | **Settings → Link, Tempo & MIDI**; habilite **Track** e **Remote** na entrada FaderDeck, conforme o uso. | Entre em MIDI Map Mode (`Cmd+M`), selecione o controle da DAW, mova o fader/pad e saia do modo de mapeamento. |
| **FL Studio** | **Options → MIDI settings**; selecione a porta em **Input** e habilite o dispositivo. | Clique com o botão direito no parâmetro e escolha **Link to controller…**; mova o controle e confirme. |
| **REAPER** | **Preferences → Audio → MIDI Devices**; habilite FaderDeck como entrada. | Use **Learn** no parâmetro ou a lista de ações para vincular a mensagem MIDI. |
| **Cubase** | **Studio → Studio Setup → MIDI Port Setup**; habilite a porta como entrada. | Configure o dispositivo em **MIDI Remote** e use o assistente de mapeamento. |
| **Logic Pro** | **Logic Pro → Settings → MIDI → Inputs**; habilite FaderDeck como entrada. | Use **Control Surfaces → Controller Assignments** e o modo Learn. |

Se um valor não responder, confira se FaderDeck está habilitado como entrada na DAW, se o MIDI Learn foi encerrado e se o app ainda está aberto na barra de menus. O botão **Panic** envia All Notes Off e Reset All Controllers.
